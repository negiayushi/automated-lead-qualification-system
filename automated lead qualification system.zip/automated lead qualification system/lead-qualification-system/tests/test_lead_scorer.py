import pytest
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from src.lead_scorer import LeadScorer
from src.data_handler import DataHandler
from src.report_generator import ReportGenerator

class TestLeadScorer:
    """Test cases for LeadScorer class"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.scorer = LeadScorer()
    
    def test_calculate_score_hot_lead(self):
        """Test scoring for a hot lead"""
        lead = {
            'budget': 'high',
            'timeline': 'immediate',
            'company_size': 'enterprise',
            'decision_maker': 'yes',
            'engagement': 'high'
        }
        score = self.scorer.calculate_score(lead)
        assert score == 100  # 30 + 25 + 20 + 15 + 10
    
    def test_calculate_score_cold_lead(self):
        """Test scoring for a cold lead"""
        lead = {
            'budget': 'low',
            'timeline': 'long',
            'company_size': 'small',
            'decision_maker': 'no',
            'engagement': 'low'
        }
        score = self.scorer.calculate_score(lead)
        assert score == 30  # 10 + 5 + 10 + 5 + 0
    
    def test_qualify_lead_hot_category(self):
        """Test lead qualification as Hot"""
        lead = {
            'name': 'Test Lead',
            'budget': 'high',
            'timeline': 'immediate',
            'company_size': 'enterprise',
            'decision_maker': 'yes',
            'engagement': 'high'
        }
        result = self.scorer.qualify_lead(lead)
        
        assert result['category'] == 'Hot'
        assert result['priority'] == 1
        assert result['score'] >= 70
    
    def test_qualify_lead_warm_category(self):
        """Test lead qualification as Warm"""
        lead = {
            'name': 'Test Lead',
            'budget': 'medium',
            'timeline': 'short',
            'company_size': 'medium',
            'decision_maker': 'yes',
            'engagement': 'medium'
        }
        result = self.scorer.qualify_lead(lead)
        
        assert result['category'] == 'Warm'
        assert result['priority'] == 2
        assert 40 <= result['score'] < 70
    
    def test_qualify_lead_cold_category(self):
        """Test lead qualification as Cold"""
        lead = {
            'name': 'Test Lead',
            'budget': 'low',
            'timeline': 'long',
            'company_size': 'small',
            'decision_maker': 'no',
            'engagement': 'low'
        }
        result = self.scorer.qualify_lead(lead)
        
        assert result['category'] == 'Cold'
        assert result['priority'] == 3
        assert result['score'] < 40
    
    def test_batch_qualify(self):
        """Test batch lead qualification"""
        leads = [
            {'budget': 'high', 'timeline': 'immediate', 'company_size': 'enterprise', 
             'decision_maker': 'yes', 'engagement': 'high'},
            {'budget': 'low', 'timeline': 'long', 'company_size': 'small', 
             'decision_maker': 'no', 'engagement': 'low'}
        ]
        
        result = self.scorer.batch_qualify(leads)
        
        assert len(result) == 2
        assert result[0]['priority'] <= result[1]['priority']  # Sorted by priority
    
    def test_invalid_criteria(self):
        """Test handling of invalid scoring criteria"""
        lead = {
            'budget': 'invalid',
            'timeline': 'unknown',
            'company_size': 'test',
            'decision_maker': 'maybe',
            'engagement': 'none'
        }
        score = self.scorer.calculate_score(lead)
        assert score == 0  # Should return 0 for all invalid values


class TestDataHandler:
    """Test cases for DataHandler class"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.handler = DataHandler('data/test_leads.json')
        # Clean up any existing test data
        if os.path.exists('data/test_leads.json'):
            os.remove('data/test_leads.json')
    
    def teardown_method(self):
        """Clean up after tests"""
        if os.path.exists('data/test_leads.json'):
            os.remove('data/test_leads.json')
    
    def test_save_and_load_leads(self):
        """Test saving and loading leads"""
        leads = [
            {'id': 1, 'name': 'Test Lead', 'score': 80, 'category': 'Hot'}
        ]
        
        assert self.handler.save_leads(leads) == True
        loaded = self.handler.load_leads()
        assert len(loaded) == 1
        assert loaded[0]['name'] == 'Test Lead'
    
    def test_add_lead(self):
        """Test adding a new lead"""
        lead = {
            'name': 'New Lead',
            'email': 'test@example.com',
            'score': 75,
            'category': 'Hot'
        }
        
        result = self.handler.add_lead(lead)
        
        assert 'id' in result
        assert 'created_at' in result
        assert result['name'] == 'New Lead'
    
    def test_get_leads_by_category(self):
        """Test filtering leads by category"""
        leads = [
            {'id': 1, 'name': 'Hot Lead', 'category': 'Hot'},
            {'id': 2, 'name': 'Cold Lead', 'category': 'Cold'},
            {'id': 3, 'name': 'Another Hot', 'category': 'Hot'}
        ]
        self.handler.save_leads(leads)
        
        hot_leads = self.handler.get_leads_by_category('Hot')
        
        assert len(hot_leads) == 2
        assert all(lead['category'] == 'Hot' for lead in hot_leads)
    
    def test_load_empty_file(self):
        """Test loading when file doesn't exist"""
        leads = self.handler.load_leads()
        assert leads == []


class TestReportGenerator:
    """Test cases for ReportGenerator class"""
    
    def setup_method(self):
        """Set up test fixtures"""
        self.sample_leads = [
            {'name': 'Lead 1', 'score': 90, 'category': 'Hot', 'email': 'lead1@test.com'},
            {'name': 'Lead 2', 'score': 50, 'category': 'Warm', 'email': 'lead2@test.com'},
            {'name': 'Lead 3', 'score': 30, 'category': 'Cold', 'email': 'lead3@test.com'}
        ]
        self.report_gen = ReportGenerator(self.sample_leads)
    
    def test_generate_summary(self):
        """Test summary report generation"""
        summary = self.report_gen.generate_summary()
        
        assert 'Total Leads: 3' in summary
        assert 'Hot Leads' in summary
        assert 'Warm Leads' in summary
        assert 'Cold Leads' in summary
    
    def test_get_top_leads(self):
        """Test getting top leads by score"""
        top_leads = self.report_gen.get_top_leads(2)
        
        assert len(top_leads) == 2
        assert top_leads[0]['score'] >= top_leads[1]['score']
        assert top_leads[0]['name'] == 'Lead 1'
    
    def test_conversion_metrics(self):
        """Test conversion metrics calculation"""
        metrics = self.report_gen.get_conversion_metrics()
        
        assert metrics['total_leads'] == 3
        assert metrics['high_potential'] == 1
        assert metrics['medium_potential'] == 1
        assert metrics['conversion_ready_percentage'] > 0
    
    def test_empty_leads(self):
        """Test report generation with no leads"""
        empty_gen = ReportGenerator([])
        summary = empty_gen.generate_summary()
        
        assert 'No leads available' in summary
    
    def test_generate_detailed_report(self):
        """Test detailed report generation"""
        report = self.report_gen.generate_detailed_report()
        
        assert 'LEAD QUALIFICATION REPORT' in report
        assert 'TOP 5 PRIORITY LEADS' in report
        assert 'Lead 1' in report


# Run tests with: pytest tests/test_lead_scorer.py -v
# Run with coverage: pytest tests/test_lead_scorer.py --cov=src --cov-report=html