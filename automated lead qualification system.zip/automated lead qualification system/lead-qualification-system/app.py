from flask import Flask, render_template, request, jsonify, send_file
from flask_cors import CORS
from flasgger import Swagger
from src.lead_scorer import LeadScorer
from src.data_handler import DataHandler
from src.report_generator import ReportGenerator
import os

app = Flask(__name__)
CORS(app)
swagger = Swagger(app)

# Initialize components
scorer = LeadScorer()
handler = DataHandler()

@app.route('/')
def index():
    """Render main dashboard"""
    return render_template('index.html')

@app.route('/api/leads', methods=['GET'])
def get_leads():
    """
    Get all leads
    ---
    responses:
      200:
        description: List of all leads
    """
    leads = handler.load_leads()
    return jsonify({'success': True, 'leads': leads, 'count': len(leads)})

@app.route('/api/leads', methods=['POST'])
def add_lead():
    """
    Add a new lead
    ---
    parameters:
      - name: body
        in: body
        required: true
        schema:
          type: object
          properties:
            name:
              type: string
            email:
              type: string
            company:
              type: string
            budget:
              type: string
            timeline:
              type: string
            company_size:
              type: string
            decision_maker:
              type: string
            engagement:
              type: string
    responses:
      201:
        description: Lead created successfully
    """
    try:
        lead_data = request.json
        
        # Validate required fields
        required_fields = ['name', 'email', 'company', 'budget', 'timeline', 
                          'company_size', 'decision_maker', 'engagement']
        
        for field in required_fields:
            if field not in lead_data:
                return jsonify({'success': False, 'error': f'Missing field: {field}'}), 400
        
        # Qualify and save lead
        qualified_lead = scorer.qualify_lead(lead_data)
        handler.add_lead(qualified_lead)
        
        return jsonify({'success': True, 'lead': qualified_lead}), 201
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/leads/category/<category>', methods=['GET'])
def get_leads_by_category(category):
    """
    Get leads by category
    ---
    parameters:
      - name: category
        in: path
        type: string
        required: true
        enum: [Hot, Warm, Cold]
    responses:
      200:
        description: List of leads in the specified category
    """
    leads = handler.get_leads_by_category(category)
    return jsonify({'success': True, 'category': category, 'leads': leads, 'count': len(leads)})

@app.route('/api/report', methods=['GET'])
def get_report():
    """
    Generate lead report
    ---
    responses:
      200:
        description: Lead qualification report
    """
    leads = handler.load_leads()
    
    if not leads:
        return jsonify({'success': False, 'error': 'No leads available'}), 404
    
    report_gen = ReportGenerator(leads)
    summary = report_gen.generate_summary()
    top_leads = report_gen.get_top_leads(5)
    metrics = report_gen.get_conversion_metrics()
    
    return jsonify({
        'success': True,
        'summary': summary,
        'top_leads': top_leads,
        'metrics': metrics
    })

@app.route('/api/stats', methods=['GET'])
def get_stats():
    """
    Get dashboard statistics
    ---
    responses:
      200:
        description: Dashboard statistics
    """
    leads = handler.load_leads()
    
    if not leads:
        return jsonify({
            'success': True,
            'stats': {
                'total': 0,
                'hot': 0,
                'warm': 0,
                'cold': 0,
                'avg_score': 0
            }
        })
    
    report_gen = ReportGenerator(leads)
    metrics = report_gen.get_conversion_metrics()
    
    hot_count = len([l for l in leads if l.get('category') == 'Hot'])
    warm_count = len([l for l in leads if l.get('category') == 'Warm'])
    cold_count = len([l for l in leads if l.get('category') == 'Cold'])
    avg_score = sum(l.get('score', 0) for l in leads) / len(leads)
    
    return jsonify({
        'success': True,
        'stats': {
            'total': len(leads),
            'hot': hot_count,
            'warm': warm_count,
            'cold': cold_count,
            'avg_score': round(avg_score, 2)
        }
    })

@app.route('/api/export/csv', methods=['GET'])
def export_csv():
    """
    Export leads to CSV
    ---
    responses:
      200:
        description: CSV file download
    """
    try:
        filename = 'leads_export.csv'
        if handler.export_to_csv(filename):
            return send_file(filename, as_attachment=True, download_name='leads.csv')
        else:
            return jsonify({'success': False, 'error': 'Export failed'}), 500
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/sample-data', methods=['POST'])
def load_sample():
    """
    Load sample data
    ---
    responses:
      201:
        description: Sample data loaded
    """
    sample_leads = [
        {
            'name': 'John Smith',
            'email': 'john@techcorp.com',
            'company': 'TechCorp Inc',
            'budget': 'high',
            'timeline': 'immediate',
            'company_size': 'enterprise',
            'decision_maker': 'yes',
            'engagement': 'high'
        },
        {
            'name': 'Sarah Johnson',
            'email': 'sarah@startup.io',
            'company': 'Startup.io',
            'budget': 'medium',
            'timeline': 'short',
            'company_size': 'small',
            'decision_maker': 'yes',
            'engagement': 'medium'
        },
        {
            'name': 'Mike Brown',
            'email': 'mike@enterprise.com',
            'company': 'Enterprise Solutions',
            'budget': 'low',
            'timeline': 'long',
            'company_size': 'medium',
            'decision_maker': 'no',
            'engagement': 'low'
        },
        {
            'name': 'Emily Davis',
            'email': 'emily@bigcorp.com',
            'company': 'BigCorp Industries',
            'budget': 'high',
            'timeline': 'immediate',
            'company_size': 'enterprise',
            'decision_maker': 'yes',
            'engagement': 'high'
        }
    ]
    
    for lead in sample_leads:
        qualified_lead = scorer.qualify_lead(lead)
        handler.add_lead(qualified_lead)
    
    return jsonify({'success': True, 'message': f'Loaded {len(sample_leads)} sample leads'}), 201

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)