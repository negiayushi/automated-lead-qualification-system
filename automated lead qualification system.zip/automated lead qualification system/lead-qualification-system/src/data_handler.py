import json
import os
from datetime import datetime

class DataHandler:
    """Handle lead data storage and retrieval"""
    
    def __init__(self, data_file='data/leads.json'):
        self.data_file = data_file
        self._ensure_data_directory()
    
    def _ensure_data_directory(self):
        """Create data directory if it doesn't exist"""
        directory = os.path.dirname(self.data_file)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)
    
    def save_leads(self, leads):
        """Save leads to JSON file"""
        try:
            with open(self.data_file, 'w') as f:
                json.dump(leads, f, indent=2)
            return True
        except Exception as e:
            print(f"Error saving leads: {e}")
            return False
    
    def load_leads(self):
        """Load leads from JSON file"""
        try:
            if os.path.exists(self.data_file):
                with open(self.data_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            print(f"Error loading leads: {e}")
            return []
    
    def add_lead(self, lead_data):
        """Add a new lead to the database"""
        leads = self.load_leads()
        
        lead_data['id'] = len(leads) + 1
        lead_data['created_at'] = datetime.now().isoformat()
        
        leads.append(lead_data)
        self.save_leads(leads)
        
        return lead_data
    
    def get_leads_by_category(self, category):
        """Retrieve leads by category (Hot/Warm/Cold)"""
        leads = self.load_leads()
        return [lead for lead in leads if lead.get('category') == category]
    
    def export_to_csv(self, filename='leads_export.csv'):
        """Export leads to CSV format"""
        try:
            import pandas as pd
            leads = self.load_leads()
            
            if leads:
                df = pd.DataFrame(leads)
                df.to_csv(filename, index=False)
                return True
            return False
        except ImportError:
            print("pandas is required for CSV export")
            return False
        except Exception as e:
            print(f"Error exporting to CSV: {e}")
            return False