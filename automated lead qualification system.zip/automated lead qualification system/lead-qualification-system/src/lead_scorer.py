class LeadScorer:
    """Automated lead qualification scoring system"""
    
    def __init__(self):
        self.scoring_criteria = {
            'budget': {'high': 30, 'medium': 20, 'low': 10},
            'timeline': {'immediate': 25, 'short': 15, 'long': 5},
            'company_size': {'enterprise': 20, 'medium': 15, 'small': 10},
            'decision_maker': {'yes': 15, 'no': 5},
            'engagement': {'high': 10, 'medium': 5, 'low': 0}
        }
    
    def calculate_score(self, lead_data):
        """Calculate lead score based on criteria"""
        score = 0
        
        for criterion, value in lead_data.items():
            if criterion in self.scoring_criteria:
                score += self.scoring_criteria[criterion].get(value, 0)
        
        return score
    
    def qualify_lead(self, lead_data):
        """Qualify lead and return category"""
        score = self.calculate_score(lead_data)
        
        lead_data['score'] = score
        
        if score >= 70:
            lead_data['category'] = 'Hot'
            lead_data['priority'] = 1
        elif score >= 40:
            lead_data['category'] = 'Warm'
            lead_data['priority'] = 2
        else:
            lead_data['category'] = 'Cold'
            lead_data['priority'] = 3
        
        return lead_data
    
    def batch_qualify(self, leads_list):
        """Qualify multiple leads"""
        qualified_leads = []
        
        for lead in leads_list:
            qualified_lead = self.qualify_lead(lead)
            qualified_leads.append(qualified_lead)
        
        return sorted(qualified_leads, key=lambda x: x['priority'])