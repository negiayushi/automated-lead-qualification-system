from collections import Counter
from datetime import datetime

class ReportGenerator:
    """Generate reports and analytics for qualified leads"""
    
    def __init__(self, leads):
        self.leads = leads
    
    def generate_summary(self):
        """Generate summary statistics"""
        if not self.leads:
            return "No leads available for reporting."
        
        total_leads = len(self.leads)
        categories = Counter(lead.get('category', 'Unknown') for lead in self.leads)
        
        avg_score = sum(lead.get('score', 0) for lead in self.leads) / total_leads
        
        summary = f"""
╔════════════════════════════════════════╗
║     LEAD QUALIFICATION REPORT          ║
╚════════════════════════════════════════╝

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

SUMMARY STATISTICS
─────────────────────────────────────────
Total Leads: {total_leads}
Average Score: {avg_score:.2f}

LEAD BREAKDOWN BY CATEGORY
─────────────────────────────────────────
Hot Leads:  {categories.get('Hot', 0)} ({categories.get('Hot', 0)/total_leads*100:.1f}%)
Warm Leads: {categories.get('Warm', 0)} ({categories.get('Warm', 0)/total_leads*100:.1f}%)
Cold Leads: {categories.get('Cold', 0)} ({categories.get('Cold', 0)/total_leads*100:.1f}%)
"""
        return summary
    
    def get_top_leads(self, n=5):
        """Get top N leads by score"""
        sorted_leads = sorted(self.leads, key=lambda x: x.get('score', 0), reverse=True)
        return sorted_leads[:n]
    
    def generate_detailed_report(self):
        """Generate detailed lead report"""
        report = self.generate_summary()
        
        report += "\n\nTOP 5 PRIORITY LEADS\n"
        report += "─────────────────────────────────────────\n"
        
        top_leads = self.get_top_leads(5)
        
        for i, lead in enumerate(top_leads, 1):
            report += f"\n{i}. {lead.get('name', 'Unknown')} "
            report += f"({lead.get('company', 'N/A')})\n"
            report += f"   Score: {lead.get('score', 0)} | "
            report += f"Category: {lead.get('category', 'Unknown')} | "
            report += f"Email: {lead.get('email', 'N/A')}\n"
        
        return report
    
    def get_conversion_metrics(self):
        """Calculate conversion potential metrics"""
        if not self.leads:
            return {}
        
        total = len(self.leads)
        hot_count = sum(1 for lead in self.leads if lead.get('category') == 'Hot')
        warm_count = sum(1 for lead in self.leads if lead.get('category') == 'Warm')
        
        return {
            'total_leads': total,
            'high_potential': hot_count,
            'medium_potential': warm_count,
            'conversion_ready_percentage': (hot_count / total * 100) if total > 0 else 0
        }