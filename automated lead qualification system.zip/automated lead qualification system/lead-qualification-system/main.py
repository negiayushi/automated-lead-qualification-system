from src.lead_scorer import LeadScorer
from src.data_handler import DataHandler
from src.report_generator import ReportGenerator

def display_menu():
    """Display main menu"""
    print("\n" + "="*50)
    print("   AUTOMATED LEAD QUALIFICATION SYSTEM")
    print("="*50)
    print("\n1. Add New Lead")
    print("2. View All Leads")
    print("3. View Leads by Category")
    print("4. Generate Report")
    print("5. Export to CSV")
    print("6. Load Sample Data")
    print("0. Exit")
    print("-"*50)

def add_new_lead(scorer, handler):
    """Add a new lead interactively"""
    print("\n--- ADD NEW LEAD ---")
    
    lead = {
        'name': input("Lead Name: "),
        'email': input("Email: "),
        'company': input("Company: "),
        'budget': input("Budget (high/medium/low): ").lower(),
        'timeline': input("Timeline (immediate/short/long): ").lower(),
        'company_size': input("Company Size (enterprise/medium/small): ").lower(),
        'decision_maker': input("Decision Maker? (yes/no): ").lower(),
        'engagement': input("Engagement Level (high/medium/low): ").lower()
    }
    
    qualified_lead = scorer.qualify_lead(lead)
    handler.add_lead(qualified_lead)
    
    print(f"\n✓ Lead added successfully!")
    print(f"  Score: {qualified_lead['score']}")
    print(f"  Category: {qualified_lead['category']}")

def view_all_leads(handler):
    """Display all leads"""
    leads = handler.load_leads()
    
    if not leads:
        print("\nNo leads found.")
        return
    
    print(f"\n--- ALL LEADS ({len(leads)}) ---")
    for lead in leads:
        print(f"\n{lead.get('name', 'Unknown')} - {lead.get('company', 'N/A')}")
        print(f"  Score: {lead.get('score', 0)} | Category: {lead.get('category', 'Unknown')}")
        print(f"  Email: {lead.get('email', 'N/A')}")

def view_by_category(handler):
    """View leads by category"""
    category = input("\nEnter category (Hot/Warm/Cold): ").capitalize()
    leads = handler.get_leads_by_category(category)
    
    if not leads:
        print(f"\nNo {category} leads found.")
        return
    
    print(f"\n--- {category.upper()} LEADS ({len(leads)}) ---")
    for lead in leads:
        print(f"\n{lead.get('name', 'Unknown')} - {lead.get('company', 'N/A')}")
        print(f"  Score: {lead.get('score', 0)}")
        print(f"  Email: {lead.get('email', 'N/A')}")

def generate_report(handler):
    """Generate and display report"""
    leads = handler.load_leads()
    
    if not leads:
        print("\nNo leads available for reporting.")
        return
    
    report_gen = ReportGenerator(leads)
    print(report_gen.generate_detailed_report())

def load_sample_data(scorer, handler):
    """Load sample leads for testing"""
    sample_leads = [
        {
            'name': 'John Smith',
            'email': 'john@techcorp.com',
            'company': 'TechCorp Inc',
            'budget': 'high',
            'timeline': 'immediate',
            'company_size': 'enterprise',
            'decision_maker': 'yes',
            'engagement': 'high'
        },
        {
            'name': 'Sarah Johnson',
            'email': 'sarah@startup.io',
            'company': 'Startup.io',
            'budget': 'medium',
            'timeline': 'short',
            'company_size': 'small',
            'decision_maker': 'yes',
            'engagement': 'medium'
        },
        {
            'name': 'Mike Brown',
            'email': 'mike@enterprise.com',
            'company': 'Enterprise Solutions',
            'budget': 'low',
            'timeline': 'long',
            'company_size': 'medium',
            'decision_maker': 'no',
            'engagement': 'low'
        }
    ]
    
    for lead in sample_leads:
        qualified_lead = scorer.qualify_lead(lead)
        handler.add_lead(qualified_lead)
    
    print(f"\n✓ Loaded {len(sample_leads)} sample leads successfully!")

def main():
    """Main application loop"""
    scorer = LeadScorer()
    handler = DataHandler()
    
    while True:
        display_menu()
        choice = input("\nEnter your choice: ")
        
        if choice == '1':
            add_new_lead(scorer, handler)
        elif choice == '2':
            view_all_leads(handler)
        elif choice == '3':
            view_by_category(handler)
        elif choice == '4':
            generate_report(handler)
        elif choice == '5':
            if handler.export_to_csv():
                print("\n✓ Data exported to leads_export.csv")
            else:
                print("\n✗ Export failed")
        elif choice == '6':
            load_sample_data(scorer, handler)
        elif choice == '0':
            print("\nThank you for using Lead Qualification System!")
            break
        else:
            print("\n✗ Invalid choice. Please try again.")

if __name__ == "__main__":
    main()