import os
from pathlib import Path

class Config:
    """Base configuration"""
    
    # Application settings
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # Data settings
    DATA_DIR = Path('data')
    DATA_FILE = DATA_DIR / 'leads.json'
    
    # Flask settings
    DEBUG = False
    TESTING = False
    
    # API settings
    API_TITLE = 'Lead Qualification System API'
    API_VERSION = '1.0.0'
    
    # Scoring thresholds
    HOT_LEAD_THRESHOLD = 70
    WARM_LEAD_THRESHOLD = 40
    
    @staticmethod
    def init_app(app):
        """Initialize application"""
        # Create data directory if it doesn't exist
        Config.DATA_DIR.mkdir(exist_ok=True)


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    DATA_FILE = Path('data/test_leads.json')


# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}